# Challenge Backend 1 - Conversor de Moedas

**Autora:** Verônica Esteves

**Nome do projeto:** ChallengeBackend1-ConversorDeMoedas  
**Java:** 17

## Descrição
Projeto do challenge "Conversor de Moedas" (Back End ONE - Alura).  
Console app que consulta cotações em tempo real usando a ExchangeRate API e realiza conversões entre moedas (USD, BRL, EUR, ARS, GBP, JPY).

## Estrutura
- `src/main/java/br/com/veronica/challenge/main/Main.java` - ponto de entrada.
- `src/main/java/br/com/veronica/challenge/service/ConversorService.java` - lógica de conversão.
- `src/main/java/br/com/veronica/challenge/api/ApiClient.java` - cliente HTTP para ExchangeRate API.
- `src/main/java/br/com/veronica/challenge/model/Moeda.java` - enum de moedas suportadas.
- `pom.xml` - arquivo Maven (opcional, facilita dependências).
- `.gitignore`

## Como configurar
1. Tenha Java 17 instalado.
2. (opcional) Instale Maven se quiser construir com `mvn package`.
3. Crie uma conta gratuita em https://www.exchangerate-api.com/ e obtenha sua API KEY.
4. No arquivo `ApiClient.java`, substitua `YOUR_API_KEY_HERE` pela sua chave.
   ```java
   private static final String API_URL = "https://v6.exchangerate-api.com/v6/YOUR_API_KEY_HERE/latest/";
   ```
5. Se usar Maven, a dependência `org.json` já está no `pom.xml`. Senão, baixe o jar `org.json` e adicione ao classpath.

## Como executar (sem Maven)
Compile:
```bash
javac -d out -cp . src/main/java/br/com/veronica/challenge/api/ApiClient.java src/main/java/br/com/veronica/challenge/service/ConversorService.java src/main/java/br/com/veronica/challenge/model/Moeda.java src/main/java/br/com/veronica/challenge/main/Main.java
```
Execute:
```bash
java -cp out br.com.veronica.challenge.main.Main
```

## Como executar com Maven
```bash
mvn package
java -jar target/ChallengeBackend1-ConversorDeMoedas-1.0.jar
```

## Observações
- A aplicação faz requisições HTTP para obter taxas; verifique sua conexão.
- A API gratuita costuma ter limites — fique atenta a isso ao testar repetidamente.

Boa sorte no challenge! Se quiser, eu te mostro como criar o repositório no GitHub e subir este projeto passo a passo.
