package br.com.veronica.challenge.main;

import br.com.veronica.challenge.service.ConversorService;
import br.com.veronica.challenge.model.Moeda;
import java.util.Scanner;

public class Main {
    private static final ConversorService conversor = new ConversorService();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Challenge Backend 1 - Conversor de Moedas ===");
        System.out.println("Autora: Verônica Esteves");
        boolean running = true;

        while (running) {
            System.out.println();
            System.out.println("Escolha a opção:");
            System.out.println("1. Dólar → Real (USD → BRL)");
            System.out.println("2. Real → Dólar (BRL → USD)");
            System.out.println("3. Euro → Real (EUR → BRL)");
            System.out.println("4. Real → Euro (BRL → EUR)");
            System.out.println("5. Peso Argentino → Real (ARS → BRL)");
            System.out.println("6. Real → Peso Argentino (BRL → ARS)");
            System.out.println("7. Libra → Real (GBP → BRL)");
            System.out.println("8. Real → Libra (BRL → GBP)");
            System.out.println("9. Yen → Real (JPY → BRL)");
            System.out.println("10. Real → Yen (BRL → JPY)");
            System.out.println("11. Converter entre siglas (qualquer par suportado)");
            System.out.println("0. Sair");
            System.out.print("Opção: ");

            int opcao = -1;
            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Opção inválida. Tente novamente.");
                continue;
            }

            try {
                switch (opcao) {
                    case 0:
                        running = false;
                        break;
                    case 1:
                        executarConversao(scanner, "USD", "BRL");
                        break;
                    case 2:
                        executarConversao(scanner, "BRL", "USD");
                        break;
                    case 3:
                        executarConversao(scanner, "EUR", "BRL");
                        break;
                    case 4:
                        executarConversao(scanner, "BRL", "EUR");
                        break;
                    case 5:
                        executarConversao(scanner, "ARS", "BRL");
                        break;
                    case 6:
                        executarConversao(scanner, "BRL", "ARS");
                        break;
                    case 7:
                        executarConversao(scanner, "GBP", "BRL");
                        break;
                    case 8:
                        executarConversao(scanner, "BRL", "GBP");
                        break;
                    case 9:
                        executarConversao(scanner, "JPY", "BRL");
                        break;
                    case 10:
                        executarConversao(scanner, "BRL", "JPY");
                        break;
                    case 11:
                        System.out.print("Digite a moeda de origem (sigla, ex: USD): ");
                        String origem = scanner.nextLine().toUpperCase();
                        System.out.print("Digite a moeda de destino (sigla, ex: BRL): ");
                        String destino = scanner.nextLine().toUpperCase();
                        if (!Moeda.contains(origem) || !Moeda.contains(destino)) {
                            System.out.println("Moeda não suportada. Use: USD, BRL, EUR, ARS, GBP, JPY");
                        } else {
                            executarConversao(scanner, origem, destino);
                        }
                        break;
                    default:
                        System.out.println("Opção inválida.");
                }
            } catch (Exception e) {
                System.out.println("Erro ao processar conversão: " + e.getMessage());
            }
        }

        System.out.println("Saindo... Obrigada e boa sorte no Challenge!");
        scanner.close();
    }

    private static void executarConversao(Scanner scanner, String origem, String destino) {
        try {
            System.out.printf("Digite o valor em %s: ", origem);
            double valor = Double.parseDouble(scanner.nextLine().replace(',', '.'));
            double resultado = conversor.converter(origem, destino, valor);
            System.out.printf("%.2f %s = %.2f %s\n", valor, origem, resultado, destino);
        } catch (NumberFormatException e) {
            System.out.println("Valor inválido.");
        } catch (Exception e) {
            System.out.println("Erro na conversão: " + e.getMessage());
        }
    }
}
