package br.com.veronica.challenge.api;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ApiClient {
    // Substitua pela sua chave
    private static final String API_URL = "https://v6.exchangerate-api.com/v6/YOUR_API_KEY_HERE/latest/";

    public double buscarTaxa(String origem, String destino) throws Exception {
        String urlStr = API_URL + origem;
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);

        int status = conn.getResponseCode();
        if (status != 200) {
            throw new RuntimeException("Erro na requisição HTTP: código " + status);
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder resposta = new StringBuilder();
        String linha;
        while ((linha = reader.readLine()) != null) {
            resposta.append(linha);
        }
        reader.close();
        conn.disconnect();

        JSONObject json = new JSONObject(resposta.toString());
        if (!json.has("conversion_rates")) {
            throw new RuntimeException("Resposta da API inesperada: " + resposta.toString());
        }
        JSONObject taxas = json.getJSONObject("conversion_rates");
        return taxas.getDouble(destino);
    }
}
