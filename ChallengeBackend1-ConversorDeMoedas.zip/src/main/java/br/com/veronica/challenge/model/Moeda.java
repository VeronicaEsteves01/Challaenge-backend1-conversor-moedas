package br.com.veronica.challenge.model;

public enum Moeda {
    USD, BRL, EUR, ARS, GBP, JPY;

    public static boolean contains(String code) {
        try {
            Moeda.valueOf(code);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
